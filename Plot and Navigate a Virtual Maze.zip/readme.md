
The program is runing in python.You can run it in the terminal interface. In the terminal interface, you first get into the program directory and use the command like:
## python tester.py test_maze_01.txt 2
The first parameter test_maze_01.txt is the maze data file. In the program root diretory,there are four maze data file. The second parameter 2 is the runing mode value. If set the value 1 or default, the program will run without graphic show. If set the value 2, the program will run with graphic show.
